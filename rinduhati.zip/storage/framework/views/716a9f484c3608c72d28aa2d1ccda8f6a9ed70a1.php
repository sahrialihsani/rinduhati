<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="<?php echo e(asset('template1/img/favicon.png')); ?>" type="image/png">
        <title>Wisata Desa Rindu Hati</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('template1/css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/linericon/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/owl-carousel/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/nice-select/css/nice-select.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/animate-css/animate.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/jquery-ui/jquery-ui.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/popup/magnific-popup.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/swiper/css/swiper.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('template1/vendors/scroll/jquery.mCustomScrollbar.css')); ?>">
        <!-- main css -->
        <link rel="stylesheet" href="<?php echo e(asset('template1/css/style.css')); ?>">
    </head>

<body>

	<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	<!--================ Start banner section =================-->
	<section style="margin-bottom: 100px" class="home-banner-area common-banner relative">
		<div class="container-fluid">
			<div class="row d-flex align-items-center justify-content-center">
				<div class="header-right col-lg-6 col-md-6">
					<h1>
						Paket Wisata
					</h1>
					<p class="pt-20">
                        Kota Bengkulu terletak di kawasan pesisir yang berhadapan langsung dengan Samudra Hindia. Kota ini memiliki luas wilayah 144,52 km² dengan ketinggian rata-rata kurang dari 500 meter. Sebagai daerah yang berada di pesisiran, Kota Bengkulu tidak memiliki wilayah yang berjarak lebih dari 30 km dari pesisir pantai.
                        Kota ini dilayani oleh Pelabuhan Pulau Baai yang merupakan pelabuhan samudera satu-satunya di Provinsi Bengkulu.
					</p>
					<div class="page-link-wrap">
						<div class="page_link">
							<a href="/">Beranda</a>
							<a style="font-weight:bold" href="paket">Paket</a>
						</div>
						<img src="<?php echo e(asset('template1/img/next.png')); ?>" alt="">
					</div>
				</div>

				<div class="col-lg-6 col-md-6 header-left">
					<div class="">
						<img class="img-fluid w-100" src="<?php echo e(asset('template1/img/paket/pantaipanjang.jpg')); ?>" alt="">
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================ End banner section =================-->

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="<?php echo e(asset('template1/js/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/js/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/js/stellar.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/isotope/imagesloaded.pkgd.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/isotope/isotope-min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/jquery-ui/jquery-ui.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/js/jquery.ajaxchimp.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/js/mail-script.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/popup/jquery.magnific-popup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/swiper/js/swiper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/vendors/scroll/jquery.mCustomScrollbar.js')); ?>"></script>
	<script src="<?php echo e(asset('template1/js/theme.js')); ?>"></script>
</body>

</html><?php /**PATH D:\rinduhati\resources\views/menus/paket.blade.php ENDPATH**/ ?>