	<!--================ Offcanvus Menu Area =================-->
	<div class="side_menu">
		<div class="logo">
			<a href="<?php echo e(asset('/')); ?>">
				<img src="<?php echo e(asset('template1/img/logo.png')); ?>" alt="">
			</a>
		</div>
		<ul class="list menu-left">
			<li>
				<a href="<?php echo e(asset('/')); ?>">Beranda</a>
			</li>
			<li>
				<div class="dropdown">
					<button type="button" class="dropdown-toggle" data-toggle="dropdown">
						Pariwisata
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="<?php echo e(asset('spot/wisata')); ?>">Spot Pariwisata</a>
						<a class="dropdown-item" href="<?php echo e(asset('spot/kategori')); ?>">Kategori</a>
					</div>
				</div>
			</li>
			<li>
				<a href="<?php echo e(asset('paket')); ?>">Paket</a>
			</li>
			
			<li>
				<a href="<?php echo e(asset('tentang_desa')); ?>">Tentang Desa</a>
			</li>
			<li>
				<div class="dropdown">
					<button type="button" class="dropdown-toggle" data-toggle="dropdown">
						Blog
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="<?php echo e(asset('blog')); ?>">Blog</a>
						<a class="dropdown-item" href="<?php echo e(asset('blog/detail_blog')); ?>">Detail Blog</a>
					</div>
				</div>
			</li>
			<li>
				<a href="<?php echo e(asset('kontak')); ?>">Kontak</a>
			</li>
		</ul>
	</div>
	<!--================ End Offcanvus Menu Area =================-->

	<!--================ Canvus Menu Area =================-->
	<div class="canvus_menu">
		<div class="container">
			<div class="toggle_icon" title="Menu Bar">
				<span></span>
			</div>
		</div>
	</div>
	<!--================ End Canvus Menu Area =================-->

	<section class="top-btn-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<a href="#" class="main_btn">
						Pesan Tempat
						<img src="<?php echo e(asset('template1/img/next.png')); ?>" alt="">
					</a>
				</div>
			</div>
		</div>
	</section><?php /**PATH D:\rinduhati\resources\views/layouts/header.blade.php ENDPATH**/ ?>