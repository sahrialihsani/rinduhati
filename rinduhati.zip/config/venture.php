<?php declare(strict_types=1);

return [
    'workflow_table' => 'workflows',
    'jobs_table' => 'workflow_jobs',
];
